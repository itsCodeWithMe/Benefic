import footerDivider from "../../favicons/footerDivider.png";
import React from "react";

function FooterImg() {
  return <img className="footerDivider w-100" src={footerDivider} alt="" />;
}

export default FooterImg;
